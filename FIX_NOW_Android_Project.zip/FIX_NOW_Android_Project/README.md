# FIX NOW — Pay ₹20 to View Number Version

FIX NOW is a local home-service booking MVP.

## Main business rule
- No monthly worker payment in the initial stage.
- Worker phone numbers are locked by default.
- Customer pays ₹20 to view a worker phone number / WhatsApp contact.
- Admin can set UPI ID inside the app under Admin → ₹20 number unlock settings.

## Important MVP note
This version uses manual UPI confirmation inside the app. For a real Play Store business version, connect Razorpay/payment gateway + server verification so phone numbers unlock only after verified payment.

## Build APK with GitHub Actions
Upload this ZIP to GitHub and run the workflow.
Artifact name: FIXNOW-debug-apk
APK inside artifact: app-debug.apk

## Latest Flow Update: Accept → Pay ₹20 → Reveal Number

This version follows the safer marketplace rule:

- Customer cannot see worker phone number immediately.
- Customer selects one specific worker and sends a request.
- Worker must accept the request first.
- Customer pays ₹20 only after the worker accepts.
- After payment confirmation, worker phone/WhatsApp is revealed.

This avoids unnecessary customer payment before worker availability is confirmed.
