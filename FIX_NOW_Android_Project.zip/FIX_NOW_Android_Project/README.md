# FIX NOW Android App

FIX NOW is an MVP Android app for a local home services business. It connects customers to local workers such as electricians, plumbers, fan repair workers, AC service workers, carpenters and painters.

## Version 1 features

- Customer service request form
- Worker directory
- Call and WhatsApp buttons
- Add/remove workers
- Job status tracking
- Commission note per job
- Export/import backup
- Offline local storage
- Android WebView wrapper
- GitHub Actions debug APK build workflow

## Package

`com.fixnow.localservice`

## Build debug APK

Open in Android Studio and select:

Build > Build Bundle(s) / APK(s) > Build APK(s)

Or upload this project to GitHub and use the included GitHub Actions workflow.
