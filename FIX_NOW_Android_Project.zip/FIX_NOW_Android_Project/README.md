# FIX NOW Online Firebase Version

FIX NOW Online is an Android WebView app that uses Firebase Firestore so workers and customers can use the app from different phones.

## Main online flow

1. Worker registers free from any place in India.
2. Registration goes to Firebase Firestore.
3. Admin approves the worker.
4. Customer searches by state, district, city and service.
5. Customer selects one specific approved worker.
6. Worker sees the request in Worker Inbox and accepts.
7. Customer pays ₹20 through UPI.
8. Customer enters the payment reference.
9. Worker phone number is revealed to the customer.

## Important setup required

This project is Firebase-ready, but it will not connect online until you edit:

`app/src/main/assets/firebase-config.js`

Paste your Firebase Web App config there.

You must enable:

- Firebase Authentication → Anonymous sign-in
- Firestore Database

## Admin

The app has a local admin passcode for test UI: `1234`.

For safer production, use Firestore security rules and add your Firebase UID into an `admins` collection.
The app shows your current UID in Admin tab after Firebase connects.

## Payment note

This MVP uses manual UPI confirmation. For a serious Play Store version, use Razorpay/Payment Gateway + server/Firebase Functions verification. Otherwise, users can type a fake reference.

## Build APK with GitHub Actions

Upload this ZIP to GitHub and run the workflow.
Artifact name: `FIXNOW-debug-apk`
APK inside artifact: `app-debug.apk`


## Live/current location update

This build adds current-location based worker search. Customers can tap **Use my current location** and search approved workers by radius. Workers can tap **Use my current location** during registration or later tap **Update live location** so customers can find nearby workers. Location is shared only when the user taps the location button.


## Live location update

This version includes live/current location support for both customers and workers:

- Customer can share/update live location for an active job.
- Worker can share/update live location for an active job.
- Both sides can use Start live / Stop live while the app is open.
- Job cards show shared location status, map links, and distance when both locations are available.

Note: this is foreground live location only. It works while the app is open. Continuous background tracking requires a native foreground service and stronger Play Store permission handling.

## Firebase Connected Build
This copy already includes the Firebase web config for project `fix-now-29f86`.
Before testing online features, enable:
1. Authentication → Sign-in method → Anonymous → Enable
2. Firestore Database → Create database
3. Firestore Rules → use `FIRESTORE_RULES_TEST.txt` for first testing


## Role-based user-friendly V2
- Added Customer / Worker / Admin mode selection.
- App hides unrelated screens after role selection.
- Customer sees only Find Worker and My Jobs.
- Worker sees only Worker Registration/Requests and My Jobs.
- Admin sees only Admin and Jobs.
- This is a UI simplification layer; Firebase online backend remains connected.
