/*
  FIX NOW Online Firebase config
  Connected to user's Firebase project: fix-now-29f86
*/
window.FIXNOW_FIREBASE_CONFIG = {
  apiKey: "AIzaSyDvRXqqfS7xpqPzjghk2Zp2BOA1mHIPIjo",
  authDomain: "fix-now-29f86.firebaseapp.com",
  projectId: "fix-now-29f86",
  storageBucket: "fix-now-29f86.firebasestorage.app",
  messagingSenderId: "452786293065",
  appId: "1:452786293065:web:82b0da86514d2913ea7298"
};

// Your UPI ID for the ₹20 unlock payment. You can change it inside Admin also.
window.FIXNOW_DEFAULT_UPI_ID = "yourupi@bank";
window.FIXNOW_UNLOCK_FEE = 20;
